import React, { useMemo } from 'react';
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from 'remotion';

export interface FilmEffectsProps {
  grain?: number;
  dust?: number;
  vignette?: number;
}

export const FilmEffects: React.FC<FilmEffectsProps> = ({
  grain = 0.5,
  dust = 0.3,
  vignette = 0.3,
}) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();

  // Procedural static/animated dust particles seeded deterministically
  const dustParticles = useMemo(() => {
    return Array.from({ length: 18 }).map((_, i) => ({
      id: i,
      top: `${((i * 17 + 23) % 97) + 1.5}%`,
      left: `${((i * 29 + 11) % 97) + 1.5}%`,
      size: (i % 3) * 1.5 + 1.5,
      opacity: 0.15 + (i % 5) * 0.08,
      triggerFrame: Math.floor((i / 18) * durationInFrames),
    }));
  }, [durationInFrames]);

  // Jitter the grain filter seed across frames for realistic film noise motion
  const grainSeed = (frame * 7) % 100;

  return (
    <AbsoluteFill style={{ pointerEvents: 'none', zIndex: 40, overflow: 'hidden' }}>
      {/* SVG Film Grain Filter */}
      {grain > 0 && (
        <>
          <svg style={{ width: 0, height: 0, position: 'absolute' }}>
            <filter id="film-grain-filter">
              <feTurbulence
                type="fractalNoise"
                baseFrequency="0.85"
                numOctaves={3}
                stitchTiles="stitch"
                seed={grainSeed}
              />
              <feColorMatrix
                type="matrix"
                values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 0.09 0"
              />
            </filter>
          </svg>
          <AbsoluteFill
            style={{
              filter: 'url(#film-grain-filter)',
              opacity: Math.min(1, Math.max(0.1, grain * 0.9)),
              mixBlendMode: 'overlay',
            }}
          />
        </>
      )}

      {/* Cinematic Vignette */}
      {vignette > 0 && (
        <AbsoluteFill
          style={{
            background: `radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,${Math.min(0.85, vignette * 0.75)}) 100%)`,
          }}
        />
      )}

      {/* Dust & Scratches Layer */}
      {dust > 0 &&
        dustParticles.map((particle) => {
          // Flicker every few frames to simulate real 35mm film specks
          const isVisible = Math.abs(((frame + particle.triggerFrame) % 14) - 7) < 2;
          if (!isVisible) return null;

          return (
            <div
              key={particle.id}
              style={{
                position: 'absolute',
                top: particle.top,
                left: particle.left,
                width: particle.size,
                height: particle.size,
                backgroundColor: '#ffffff',
                borderRadius: '50%',
                opacity: particle.opacity * dust,
                boxShadow: '0 0 2px rgba(255, 255, 255, 0.4)',
              }}
            />
          );
        })}
    </AbsoluteFill>
  );
};
