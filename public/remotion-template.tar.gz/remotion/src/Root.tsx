import React from 'react';
import { Composition } from 'remotion';
import { StoryboardVideo } from './StoryboardVideo';
import { StoryboardVideoProps } from './types';

const defaultStoryboardProps: StoryboardVideoProps = {
  title: 'ContentGen AI Video',
  aspectRatio: '16:9',
  totalDurationSec: 10,
  subtitlesEnabled: true,
  subtitleStyle: {
    preset: 'classic',
    textColor: '#ffffff',
    bgColor: 'rgba(0,0,0,0.75)',
    position: 'bottom',
  },
  clips: [
    {
      id: 'shot-1',
      startTime: 0,
      endTime: 5,
      duration: 5,
      text: 'AI-Generated Storyboard on Google Cloud Run',
      camera_movement: 'slow_zoom_in',
    },
    {
      id: 'shot-2',
      startTime: 5,
      endTime: 10,
      duration: 5,
      text: 'Rendered at Scale with Remotion & Cloud Run',
      camera_movement: 'pan_left',
    },
  ],
};

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition<any, any>
        id="StoryboardVideo"
        component={StoryboardVideo}
        durationInFrames={300}
        fps={30}
        width={1920}
        height={1080}
        defaultProps={defaultStoryboardProps}
        calculateMetadata={async ({ props }) => {
          const p = (props || {}) as unknown as StoryboardVideoProps;
          const fps = 30;
          const clips = p.clips || [];
          const totalDuration =
            p.totalDurationSec ||
            (clips.length > 0
              ? clips.reduce(
                  (max: number, c: any) => Math.max(max, (c.startTime || 0) + (c.duration || 0)),
                  0
                )
              : 10);

          const durationInFrames = Math.max(
            30,
            Math.round(totalDuration * fps)
          );

          let width = 1920;
          let height = 1080;

          switch (props.aspectRatio) {
            case '9:16':
              width = 1080;
              height = 1920;
              break;
            case '1:1':
              width = 1080;
              height = 1080;
              break;
            case '4:3':
              width = 1440;
              height = 1080;
              break;
            case '3:4':
              width = 1080;
              height = 1440;
              break;
            case '16:9':
            default:
              width = 1920;
              height = 1080;
              break;
          }

          return {
            durationInFrames,
            width,
            height,
            fps,
          };
        }}
      />
    </>
  );
};
