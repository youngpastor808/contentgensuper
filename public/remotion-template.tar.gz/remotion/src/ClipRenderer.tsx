import React from 'react';
import { AbsoluteFill, CanvasImage, Img, Audio, useCurrentFrame, useVideoConfig, interpolate } from 'remotion';
import { Video } from '@remotion/media';
import { TimelineClipProp, SubtitleStyleConfig, VideoEffectsConfig } from './types';
import { CameraPanZoom } from './CameraPanZoom';
import { SubtitlesOverlay } from './SubtitlesOverlay';
import { CornerMapCallout } from './CornerMapCallout';
import { customStudioPostEffects } from './effects/customStudioEffects';

interface ClipRendererProps {
  clip: TimelineClipProp;
  subtitlesEnabled: boolean;
  subtitleStyle?: SubtitleStyleConfig;
  durationInFrames: number;
  videoEffects?: VideoEffectsConfig;
}

export const ClipRenderer: React.FC<ClipRendererProps> = ({
  clip,
  subtitlesEnabled,
  subtitleStyle,
  durationInFrames,
  videoEffects,
}) => {
  const frame = useCurrentFrame();
  const hasVideo = Boolean(clip.videoUrl);
  const hasImage = Boolean(clip.imageUrl);

  // Compute active effect parameters
  const grain = videoEffects?.grain ?? 0;
  const chromaticAberration = videoEffects?.chromaticAberration ?? 0;
  const vignette = videoEffects?.vignette ?? (videoEffects?.cinematicVignette ? 0.6 : 0);
  const filterName = videoEffects?.colorFilter ?? 'none';
  const hasCustomEffects = grain > 0 || chromaticAberration > 0 || vignette > 0 || (filterName && filterName !== 'none');

  const { fps } = useVideoConfig();

  // Transitions and Fades
  const fadeInFrames = Math.max(0, Math.round((clip.fadeIn || 0) * fps));
  const fadeOutFrames = Math.max(0, Math.round((clip.fadeOut || 0) * fps));
  const transitionToNext = clip.transitionToNext || 'cut';
  const transitionDurationSec = clip.transitionDuration || 0.35;
  const transitionFrames = Math.max(0, Math.round(transitionDurationSec * fps));

  let clipOpacity = 1;
  let transform = '';

  if (fadeInFrames > 0 && frame < fadeInFrames) {
    clipOpacity = interpolate(frame, [0, fadeInFrames], [0, 1], { extrapolateRight: 'clamp' });
  }

  if (fadeOutFrames > 0 && frame > durationInFrames - fadeOutFrames) {
    const fadeOutOpacity = interpolate(frame, [durationInFrames - fadeOutFrames, durationInFrames], [1, 0], { extrapolateLeft: 'clamp' });
    clipOpacity = Math.min(clipOpacity, fadeOutOpacity);
  }

  // Handle transition out to next clip
  if (transitionToNext !== 'cut' && transitionFrames > 0 && frame > durationInFrames - transitionFrames) {
    const tProgress = interpolate(frame, [durationInFrames - transitionFrames, durationInFrames], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
    if (transitionToNext === 'fade' || transitionToNext === 'crossfade') {
      clipOpacity = Math.min(clipOpacity, 1 - tProgress);
    } else if (transitionToNext === 'zoomdissolve') {
      clipOpacity = Math.min(clipOpacity, 1 - tProgress);
      transform = `scale(${1 + tProgress * 0.15})`;
    } else if (transitionToNext === 'swipeleft') {
      transform = `translateX(-${tProgress * 100}%)`;
    } else if (transitionToNext === 'swiperight') {
      transform = `translateX(${tProgress * 100}%)`;
    } else if (transitionToNext === 'swipeup') {
      transform = `translateY(-${tProgress * 100}%)`;
    } else if (transitionToNext === 'swipedown') {
      transform = `translateY(${tProgress * 100}%)`;
    }
  }

  return (
    <AbsoluteFill style={{ backgroundColor: '#09090b', overflow: 'hidden', opacity: clipOpacity, transform: transform || undefined }}>
      {/* Visual Canvas Layer with Pan/Zoom */}
      <CameraPanZoom
        cameraMovement={clip.camera_movement}
        cameraKeyframes={clip.cameraKeyframes}
        durationInFrames={durationInFrames}
      >
        {hasVideo ? (
          <Video
            src={clip.videoUrl!}
            style={{
              width: '100%',
              height: '100%',
            }}
            objectFit="cover"
            volume={clip.volume !== undefined ? clip.volume : 1.0}
            effects={
              hasCustomEffects
                ? [
                    customStudioPostEffects({
                      grain,
                      chromaticAberration,
                      vignette,
                      filterName,
                      seed: frame,
                    }),
                  ]
                : undefined
            }
          />
        ) : hasImage ? (
          hasCustomEffects ? (
            <CanvasImage
              src={clip.imageUrl!}
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
              }}
              effects={[
                customStudioPostEffects({
                  grain,
                  chromaticAberration,
                  vignette,
                  filterName,
                  seed: frame,
                }),
              ]}
            />
          ) : (
            <Img
              src={clip.imageUrl!}
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
              }}
            />
          )
        ) : (
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              height: '100%',
              backgroundColor: '#18181b',
              color: '#a1a1aa',
              padding: 40,
              textAlign: 'center',
              fontFamily: 'system-ui, -apple-system, sans-serif',
            }}
          >
            <div style={{ fontSize: 48, marginBottom: 16 }}>🎬</div>
            <div style={{ fontSize: 24, fontWeight: 600, color: '#f4f4f5' }}>
              {clip.text || `Shot ${clip.id}`}
            </div>
          </div>
        )}
      </CameraPanZoom>

      {/* Picture-in-Picture / Talking Head mode */}
      {clip.talkingHeadMode && clip.talkingHeadMode !== 'none' && clip.imageUrl && hasVideo && (
        <div
          style={{
            position: 'absolute',
            bottom: '5%',
            right: '5%',
            width: '24%',
            aspectRatio: '1/1',
            borderRadius: clip.talkingHeadShape === 'circle' ? '50%' : '16px',
            overflow: 'hidden',
            boxShadow: '0 8px 30px rgba(0,0,0,0.7)',
            border: '3px solid rgba(255, 255, 255, 0.9)',
            zIndex: 30,
          }}
        >
          <Img
            src={clip.imageUrl}
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
        </div>
      )}

      {/* Clip-specific audio / SFX */}
      {clip.audioUrl && (
        <Audio
          src={clip.audioUrl}
          volume={clip.volume !== undefined ? clip.volume : 1.0}
        />
      )}
      {clip.sfxUrl && <Audio src={clip.sfxUrl} volume={0.8} />}

      {/* Corner Map / Media Callout Overlay */}
      {(clip.hasCornerMapCallout || clip.overlayImageUrl) && (
        <CornerMapCallout
          label={clip.cornerCalloutLabel || 'SYS_LOC // TARGET'}
          gridCoordinates={clip.cornerCalloutCoords || 'GRID: 45.892, -122.104'}
          overlayImageUrl={clip.overlayImageUrl}
          durationInFrames={durationInFrames}
        />
      )}

      {/* Subtitles Layer */}
      {subtitlesEnabled && (clip.text || (clip.subtitles && clip.subtitles.length > 0)) && (
        <SubtitlesOverlay
          text={clip.text}
          subtitles={clip.subtitles}
          styleConfig={subtitleStyle}
        />
      )}
    </AbsoluteFill>
  );
};
