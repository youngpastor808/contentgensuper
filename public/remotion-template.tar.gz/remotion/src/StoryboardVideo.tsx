import React from 'react';
import { AbsoluteFill, Sequence, Audio, useVideoConfig } from 'remotion';
import { StoryboardVideoProps } from './types';
import { ClipRenderer } from './ClipRenderer';
import { FilmEffects } from './FilmEffects';
import { SubtitlesOverlay } from './SubtitlesOverlay';

export const StoryboardVideo: React.FC<StoryboardVideoProps> = ({
  clips = [],
  subtitlesEnabled = true,
  subtitles = [],
  subtitleStyle,
  textOverlays = [],
  masterAudioUrl,
  backgroundMusicUrl,
  backgroundMusicVolume = 0.25,
  videoEffects,
}) => {
  const { fps } = useVideoConfig();

  const grain = videoEffects?.grain ?? 0;
  const dust = videoEffects?.dustAndScratches ?? 0;
  const vignette = videoEffects?.vignette ?? (videoEffects?.cinematicVignette ? 0.6 : 0);
  const hasFilmEffects = grain > 0 || dust > 0 || vignette > 0;

  return (
    <AbsoluteFill style={{ backgroundColor: '#000000' }}>
      {/* Visual Clips Sequenced Along Timeline */}
      {clips.map((clip) => {
        const fromFrame = Math.max(0, Math.round(clip.startTime * fps));
        const durationFrames = Math.max(1, Math.round(clip.duration * fps));

        return (
          <Sequence
            key={clip.id}
            from={fromFrame}
            durationInFrames={durationFrames}
          >
            <ClipRenderer
              clip={clip}
              subtitlesEnabled={subtitlesEnabled}
              subtitleStyle={subtitleStyle}
              durationInFrames={durationFrames}
              videoEffects={videoEffects}
            />
          </Sequence>
        );
      })}

      {/* Global Timeline Text Overlays (Lower Thirds, Title Cards, Floating Headers) */}
      {textOverlays.map((overlay, idx) => {
        const startFrame = Math.max(0, Math.round((overlay.startTime || 0) * fps));
        const durFrame = Math.max(1, Math.round(((overlay.endTime || overlay.startTime + 3) - overlay.startTime) * fps));

        const isTop = overlay.position?.includes('top');
        const isBottom = overlay.position?.includes('bottom') || !isTop;
        const isLeft = overlay.position?.includes('left');
        const isRight = overlay.position?.includes('right');

        return (
          <Sequence key={`txt_ov_${overlay.id || idx}`} from={startFrame} durationInFrames={durFrame}>
            <div
              style={{
                position: 'absolute',
                top: isTop ? '8%' : isBottom ? 'auto' : '50%',
                bottom: isBottom ? '8%' : 'auto',
                left: isLeft ? '6%' : isRight ? 'auto' : '5%',
                right: isRight ? '6%' : isLeft ? 'auto' : '5%',
                transform: !isTop && !isBottom ? 'translateY(-50%)' : undefined,
                textAlign: isLeft ? 'left' : isRight ? 'right' : 'center',
                zIndex: 60,
                pointerEvents: 'none',
              }}
            >
              <span
                style={{
                  display: 'inline-block',
                  backgroundColor: overlay.backgroundColor || 'rgba(0,0,0,0.85)',
                  color: overlay.color || '#ffffff',
                  fontSize: overlay.fontSize || 36,
                  fontWeight: 800,
                  padding: '12px 24px',
                  borderRadius: 8,
                  boxShadow: '0 8px 30px rgba(0,0,0,0.7)',
                  fontFamily: 'system-ui, -apple-system, sans-serif',
                  letterSpacing: '0.02em',
                }}
              >
                {overlay.text}
              </span>
            </div>
          </Sequence>
        );
      })}

      {/* Global Subtitles Layer */}
      {subtitlesEnabled && subtitles && subtitles.length > 0 && (
        <SubtitlesOverlay
          subtitles={subtitles}
          styleConfig={subtitleStyle}
        />
      )}

      {/* Cinematic Film Effects & Overlays Layer (Grain, Dust Particles, Vignette) */}
      {hasFilmEffects && (
        <FilmEffects
          grain={grain}
          dust={dust}
          vignette={vignette}
        />
      )}

      {/* Master Narration Track */}
      {masterAudioUrl && (
        <Audio
          src={masterAudioUrl}
          volume={1.0}
        />
      )}

      {/* Background Music Track */}
      {backgroundMusicUrl && (
        <Audio
          src={backgroundMusicUrl}
          volume={backgroundMusicVolume}
          loop
        />
      )}
    </AbsoluteFill>
  );
};
