import React from 'react';
import { interpolate, useCurrentFrame, useVideoConfig } from 'remotion';
import { CameraKeyframesConfig } from './types';

interface CameraPanZoomProps {
  cameraMovement?: string;
  cameraKeyframes?: CameraKeyframesConfig;
  durationInFrames: number;
  children: React.ReactNode;
}

export const CameraPanZoom: React.FC<CameraPanZoomProps> = ({
  cameraMovement = 'static',
  cameraKeyframes,
  durationInFrames,
  children,
}) => {
  const frame = useCurrentFrame();
  const safeDuration = Math.max(1, durationInFrames);
  const progress = Math.min(1, Math.max(0, frame / safeDuration));

  let scale = 1.0;
  let translateX = 0;
  let translateY = 0;
  let rotation = 0;

  if (cameraKeyframes) {
    const { start, end } = cameraKeyframes;
    scale = interpolate(progress, [0, 1], [start.scale, end.scale], {
      extrapolateRight: 'clamp',
    });
    const xPct = interpolate(progress, [0, 1], [start.x, end.x], {
      extrapolateRight: 'clamp',
    });
    const yPct = interpolate(progress, [0, 1], [start.y, end.y], {
      extrapolateRight: 'clamp',
    });
    translateX = (0.5 - xPct) * 100;
    translateY = (0.5 - yPct) * 100;
    if (start.rotation !== undefined || end.rotation !== undefined) {
      rotation = interpolate(
        progress,
        [0, 1],
        [start.rotation || 0, end.rotation || 0],
        { extrapolateRight: 'clamp' }
      );
    }
  } else {
    // Flexible preset camera movements matching ContentGen AI
    const mov = (cameraMovement || '').toLowerCase().trim();

    if (mov.includes('zoom_out') || mov.includes('zoomout') || mov.includes('slow_zoom_out')) {
      scale = interpolate(progress, [0, 1], [1.15, 1.0], { extrapolateRight: 'clamp' });
    } else if (mov.includes('zoom_in') || mov.includes('zoomin') || mov.includes('slow_zoom_in') || mov.includes('ken_burns') || mov.includes('zoom')) {
      scale = interpolate(progress, [0, 1], [1.0, 1.15], { extrapolateRight: 'clamp' });
    } else if (mov.includes('pan_left') || mov.includes('panleft') || mov.includes('left')) {
      scale = 1.08;
      translateX = interpolate(progress, [0, 1], [4, -4], { extrapolateRight: 'clamp' });
    } else if (mov.includes('pan_right') || mov.includes('panright') || mov.includes('right')) {
      scale = 1.08;
      translateX = interpolate(progress, [0, 1], [-4, 4], { extrapolateRight: 'clamp' });
    } else if (mov.includes('pan_up') || mov.includes('tilt_up') || mov.includes('up')) {
      scale = 1.08;
      translateY = interpolate(progress, [0, 1], [3, -3], { extrapolateRight: 'clamp' });
    } else if (mov.includes('pan_down') || mov.includes('tilt_down') || mov.includes('down')) {
      scale = 1.08;
      translateY = interpolate(progress, [0, 1], [-3, 3], { extrapolateRight: 'clamp' });
    } else if (mov.includes('drone') || mov.includes('flyover') || mov.includes('dynamic') || mov.includes('orbit')) {
      scale = interpolate(progress, [0, 1], [1.02, 1.15], { extrapolateRight: 'clamp' });
      translateY = interpolate(progress, [0, 1], [2, -2], { extrapolateRight: 'clamp' });
      rotation = interpolate(progress, [0, 1], [-1, 1], { extrapolateRight: 'clamp' });
    } else {
      // Default subtle organic motion so still images are never completely frozen
      scale = interpolate(progress, [0, 1], [1.0, 1.08], { extrapolateRight: 'clamp' });
      translateY = interpolate(progress, [0, 1], [0.5, -0.5], { extrapolateRight: 'clamp' });
    }
  }

  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        transformOrigin: 'center center',
        transform: `translate(${translateX}%, ${translateY}%) scale(${scale}) rotate(${rotation}deg)`,
        willChange: 'transform',
      }}
    >
      {children}
    </div>
  );
};
