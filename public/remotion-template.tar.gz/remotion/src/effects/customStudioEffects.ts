import { createEffect } from 'remotion';

export interface CinematicCustomEffectsParams {
  grain?: number;
  chromaticAberration?: number;
  vignette?: number;
  filterName?: string;
  seed?: number;
}

/**
 * Custom Remotion Canvas Effect executing with 100% pixel parity on 2D / Canvas pipelines.
 * Compatible with Remotion's `createEffect()` API for AWS Lambda, headless renderers, and preview.
 */
export const customStudioPostEffects = createEffect<CinematicCustomEffectsParams, null>({
  type: 'ai.studio.customPostEffects',
  label: 'Studio Cinematic Effects',
  documentationLink: null,
  backend: '2d',
  calculateKey: (params) => {
    return `fx-${params.filterName || 'none'}-${params.grain || 0}-${params.vignette || 0}-${params.chromaticAberration || 0}-${params.seed || 0}`;
  },
  setup: () => null,
  apply: ({ source, target, width, height, params }) => {
    const ctx = target.getContext('2d');
    if (!ctx) return;

    // Draw base source
    ctx.clearRect(0, 0, width, height);
    ctx.drawImage(source, 0, 0, width, height);

    const { grain = 0, chromaticAberration = 0, vignette = 0, filterName = 'none', seed = 0 } = params;

    // 1. Color Grading Filter / LUT approximation
    if (filterName && filterName !== 'none') {
      const imgData = ctx.getImageData(0, 0, width, height);
      const { data } = imgData;

      for (let i = 0; i < data.length; i += 4) {
        let r = data[i];
        let g = data[i + 1];
        let b = data[i + 2];

        switch (filterName) {
          case 'noir':
          case 'black_and_white': {
            const gray = 0.299 * r + 0.587 * g + 0.114 * b;
            data[i] = gray;
            data[i + 1] = gray;
            data[i + 2] = gray;
            break;
          }
          case 'sepia': {
            data[i] = Math.min(255, r * 0.393 + g * 0.769 + b * 0.189);
            data[i + 1] = Math.min(255, r * 0.349 + g * 0.686 + b * 0.168);
            data[i + 2] = Math.min(255, r * 0.272 + g * 0.534 + b * 0.131);
            break;
          }
          case 'warm_cinematic':
          case 'warm': {
            data[i] = Math.min(255, r + 14);
            data[i + 1] = Math.min(255, g + 4);
            data[i + 2] = Math.max(0, b - 12);
            break;
          }
          case 'cool':
          case 'cyberpunk': {
            data[i] = Math.max(0, r - 8);
            data[i + 1] = Math.min(255, g + 6);
            data[i + 2] = Math.min(255, b + 18);
            break;
          }
          case 'high_contrast': {
            data[i] = r > 128 ? Math.min(255, r + 20) : Math.max(0, r - 20);
            data[i + 1] = g > 128 ? Math.min(255, g + 20) : Math.max(0, g - 20);
            data[i + 2] = b > 128 ? Math.min(255, b + 20) : Math.max(0, b - 20);
            break;
          }
        }
      }

      ctx.putImageData(imgData, 0, 0);
    }

    // 2. Chromatic Aberration (Channel-split offset)
    if (chromaticAberration > 0) {
      const shift = Math.round(chromaticAberration * 4);
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      ctx.globalAlpha = 0.25 * chromaticAberration;
      ctx.drawImage(source, shift, 0, width, height, 0, 0, width, height);
      ctx.globalCompositeOperation = 'multiply';
      ctx.drawImage(source, -shift, 0, width, height, 0, 0, width, height);
      ctx.restore();
    }

    // 3. Cinematic Vignette (Radial Falloff)
    if (vignette > 0) {
      ctx.save();
      const grad = ctx.createRadialGradient(
        width / 2,
        height / 2,
        height * 0.28,
        width / 2,
        height / 2,
        width * 0.78
      );
      grad.addColorStop(0, 'rgba(0, 0, 0, 0)');
      grad.addColorStop(1, `rgba(0, 0, 0, ${Math.min(0.85, vignette * 0.65)})`);
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
      ctx.restore();
    }

    // 4. Deterministic Film Noise & Grain
    if (grain > 0) {
      ctx.save();
      ctx.globalCompositeOperation = 'overlay';
      ctx.globalAlpha = 0.06 * grain;
      let s = (seed * 1664525 + 1013904223) & 0xffffffff;
      const rand = () => {
        s = (s * 1664525 + 1013904223) & 0xffffffff;
        return (s >>> 0) / 0xffffffff;
      };

      const dotCount = Math.round(90 * grain);
      for (let i = 0; i < dotCount; i++) {
        const gx = rand() * width;
        const gy = rand() * height;
        ctx.fillStyle = rand() > 0.5 ? '#ffffff' : '#000000';
        ctx.fillRect(gx, gy, 2, 2);
      }
      ctx.restore();
    }
  },
  cleanup: () => undefined,
  schema: {} as any,
  validateParams: () => {},
});
