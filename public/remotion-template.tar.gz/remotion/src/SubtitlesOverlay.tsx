import React from 'react';
import { SubtitleStyleConfig, SubtitleCue } from './types';
import { useCurrentFrame, useVideoConfig } from 'remotion';

interface SubtitlesOverlayProps {
  text?: string;
  subtitles?: SubtitleCue[];
  styleConfig?: SubtitleStyleConfig;
}

export const SubtitlesOverlay: React.FC<SubtitlesOverlayProps> = ({
  text,
  subtitles,
  styleConfig = {},
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const currentTimeSec = frame / fps;

  // If fine-grained subtitle cues are provided, select current cue
  let activeText = text || '';
  if (subtitles && subtitles.length > 0) {
    const activeCue = subtitles.find(
      (cue) => currentTimeSec >= cue.start && currentTimeSec <= cue.end
    );
    if (activeCue) {
      activeText = activeCue.text;
    } else if (!text) {
      return null;
    }
  }

  if (!activeText.trim()) return null;

  const preset = styleConfig.preset || 'classic';
  const position = styleConfig.position || 'bottom';
  const textColor = styleConfig.textColor || '#ffffff';
  const highlightColor = styleConfig.highlightColor || '#fbbf24';
  const bgColor = styleConfig.bgColor || 'rgba(0, 0, 0, 0.75)';

  const positionStyles: React.CSSProperties = {
    position: 'absolute',
    left: '6%',
    right: '6%',
    textAlign: 'center',
    zIndex: 50,
    pointerEvents: 'none',
    ...(position === 'top'
      ? { top: '8%' }
      : position === 'center'
      ? { top: '50%', transform: 'translateY(-50%)' }
      : { bottom: '8%' }),
  };

  if (preset === 'tiktok') {
    return (
      <div style={positionStyles}>
        <span
          style={{
            fontFamily: styleConfig.fontFamily || 'system-ui, -apple-system, sans-serif',
            fontSize: styleConfig.fontSize || 42,
            fontWeight: 900,
            textTransform: 'uppercase',
            color: highlightColor,
            WebkitTextStroke: '2px #000000',
            textShadow: '0 4px 12px rgba(0,0,0,0.85), 0 2px 4px rgba(0,0,0,0.9)',
            display: 'inline-block',
            padding: '8px 16px',
            letterSpacing: '0.02em',
          }}
        >
          {activeText}
        </span>
      </div>
    );
  }

  if (preset === 'cinema') {
    return (
      <div style={positionStyles}>
        <span
          style={{
            fontFamily: styleConfig.fontFamily || 'Georgia, serif',
            fontSize: styleConfig.fontSize || 32,
            fontStyle: 'italic',
            color: '#fef08a',
            textShadow: '0 2px 8px rgba(0,0,0,0.95)',
            letterSpacing: '0.05em',
          }}
        >
          "{activeText}"
        </span>
      </div>
    );
  }

  // Default / Classic box
  return (
    <div style={positionStyles}>
      <span
        style={{
          fontFamily: styleConfig.fontFamily || 'system-ui, -apple-system, sans-serif',
          fontSize: styleConfig.fontSize || 34,
          fontWeight: 700,
          color: textColor,
          backgroundColor: bgColor,
          padding: '10px 22px',
          borderRadius: 10,
          boxShadow: '0 4px 20px rgba(0,0,0,0.6)',
          lineHeight: 1.4,
          display: 'inline-block',
          maxWidth: '90%',
        }}
      >
        {activeText}
      </span>
    </div>
  );
};
