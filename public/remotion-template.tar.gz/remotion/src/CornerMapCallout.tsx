import React from 'react';
import { spring, useCurrentFrame, useVideoConfig, Img } from 'remotion';

export interface CornerCalloutProps {
  label?: string;
  gridCoordinates?: string;
  altitude?: string;
  overlayImageUrl?: string;
  durationInFrames: number;
}

export const CornerMapCallout: React.FC<CornerCalloutProps> = ({
  label = 'SYS_LOC // TARGET',
  gridCoordinates = 'GRID: 45.892, -122.104',
  altitude,
  overlayImageUrl,
  durationInFrames,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // Smooth entry animation
  const entrance = spring({
    frame,
    fps,
    config: { damping: 15, mass: 0.8 },
  });

  // Smooth exit animation during final 15% of clip
  const exitStartFrame = Math.max(0, durationInFrames - Math.round(fps * 0.4));
  let exitScale = 1.0;
  if (frame > exitStartFrame) {
    const exitProgress = Math.min(1, (frame - exitStartFrame) / Math.max(1, fps * 0.4));
    exitScale = 1.0 - exitProgress;
  }

  const combinedScale = Math.max(0, entrance * exitScale);
  if (combinedScale <= 0.01) return null;

  return (
    <div
      style={{
        position: 'absolute',
        bottom: '6%',
        left: '5%',
        transform: `scale(${combinedScale})`,
        transformOrigin: 'bottom left',
        fontFamily: 'monospace, -apple-system, sans-serif',
        color: '#00ffcc',
        zIndex: 35,
        pointerEvents: 'none',
      }}
    >
      <div
        style={{
          borderLeft: '3px solid #00ffcc',
          borderBottom: '3px solid #00ffcc',
          padding: '12px 14px',
          minWidth: '220px',
          maxWidth: '320px',
          background: 'rgba(9, 9, 11, 0.75)',
          backdropFilter: 'blur(8px)',
          borderRadius: '0 8px 0 0',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.8), 0 0 15px rgba(0, 255, 204, 0.2)',
        }}
      >
        {/* Optional overlay thumbnail (e.g. mini map plate) */}
        {overlayImageUrl && (
          <div
            style={{
              width: '100%',
              height: '80px',
              marginBottom: '8px',
              borderRadius: '4px',
              overflow: 'hidden',
              border: '1px solid rgba(0, 255, 204, 0.3)',
            }}
          >
            <Img
              src={overlayImageUrl}
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
          </div>
        )}

        <div
          style={{
            fontSize: '11px',
            letterSpacing: '1.5px',
            fontWeight: 'bold',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
          }}
        >
          <span
            style={{
              display: 'inline-block',
              width: '6px',
              height: '6px',
              borderRadius: '50%',
              backgroundColor: '#00ffcc',
              boxShadow: '0 0 8px #00ffcc',
            }}
          />
          {label}
        </div>

        <div
          style={{
            fontSize: '14px',
            margin: '4px 0',
            color: '#f4f4f5',
            fontWeight: 600,
            letterSpacing: '0.5px',
          }}
        >
          {gridCoordinates}
        </div>

        <div style={{ fontSize: '10px', color: '#a1a1aa', opacity: 0.85 }}>
          {altitude || `ALT: ${(1240 + frame * 1.5).toFixed(1)}m | TRK_0${Math.floor(frame / 12) % 9}`}
        </div>
      </div>
    </div>
  );
};
