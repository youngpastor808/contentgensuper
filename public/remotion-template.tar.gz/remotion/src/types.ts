export interface CameraKeyframe {
  x: number;          // Normalized center (0.0 = left, 0.5 = center, 1.0 = right)
  y: number;          // Normalized center (0.0 = top, 0.5 = center, 1.0 = bottom)
  scale: number;      // Zoom factor (e.g. 1.0 to 1.3)
  rotation?: number;  // Rotation in degrees
}

export interface CameraKeyframesConfig {
  start: CameraKeyframe;
  end: CameraKeyframe;
  easing?: 'linear' | 'easeInOut' | 'easeIn' | 'easeOut' | 'whip';
}

export interface SubtitleCue {
  text: string;
  start: number; // in seconds
  end: number;   // in seconds
}

export interface TimelineClipProp {
  id: string;
  startTime: number;  // in seconds
  endTime: number;    // in seconds
  duration: number;   // in seconds
  text?: string;
  hasVideo?: boolean;
  hasImage?: boolean;
  imageUrl?: string;
  videoUrl?: string;
  audioUrl?: string;
  sfxUrl?: string;
  talkingHeadMode?: 'full' | 'pip-br' | 'pip-bl' | 'pip-tr' | 'pip-tl' | 'split' | 'none';
  talkingHeadShape?: 'circle' | 'rounded' | 'square';
  camera_movement?: string;
  cameraKeyframes?: CameraKeyframesConfig;
  volume?: number;
  fadeIn?: number;
  fadeOut?: number;
  transitionToNext?: 'cut' | 'fade' | 'crossfade' | 'zoomdissolve' | 'swipeleft' | 'swiperight' | 'swipeup' | 'swipedown' | 'wipe' | 'blur' | 'glitch' | string;
  transitionDuration?: number;
  subtitles?: SubtitleCue[];
  overlayImageUrl?: string;
  hasCornerMapCallout?: boolean;
  cornerCalloutLabel?: string;
  cornerCalloutCoords?: string;
}

export interface VideoEffectsConfig {
  grain?: number;
  dustAndScratches?: number;
  vignette?: number;
  colorFilter?: string;
  cinematicVignette?: boolean;
  chromaticAberration?: number;
  lightLeaks?: number;
  sparkles?: number;
}

export interface SubtitleStyleConfig {
  preset?: 'classic' | 'tiktok' | 'karaoke' | 'minimal_bar' | 'cinema';
  textColor?: string;
  highlightColor?: string;
  bgColor?: string;
  fontSize?: number;
  fontFamily?: string;
  position?: 'bottom' | 'center' | 'top';
}

export interface TextOverlayProp {
  id?: string;
  text: string;
  type?: 'title' | 'lower_third' | 'subtitle' | 'caption' | 'callout' | string;
  startTime: number;
  endTime: number;
  position?: 'top' | 'center' | 'bottom' | 'top_left' | 'top_right' | 'bottom_left' | 'bottom_right';
  fontSize?: number;
  color?: string;
  backgroundColor?: string;
}

export interface StoryboardVideoProps {
  title: string;
  aspectRatio: '16:9' | '9:16' | '1:1' | '4:3' | '3:4';
  clips: TimelineClipProp[];
  totalDurationSec: number;
  subtitlesEnabled: boolean;
  subtitles?: SubtitleCue[];
  subtitleStyle?: SubtitleStyleConfig;
  textOverlays?: TextOverlayProp[];
  masterAudioUrl?: string;
  backgroundMusicUrl?: string;
  backgroundMusicVolume?: number;
  videoEffects?: VideoEffectsConfig;
}
